% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

function U = DeePC_OSQP(N,Tini,T, UP, YP, UF,YF,lambda_g,x_ini,t,lambda_y, Q, R,r)
% This function will solve the DeePC optimization problem by using OSQP.

m = 1;
p = 1;

ub = [1000;1000];
lb = [-1000;-1000];

global osqpSolver;

if t == 0
    % We initialize the sovler at t = 0.
    H = blkdiag([UF]'* R * [UF] + Q * (YF'*YF) + lambda_g * eye(T-Tini-N+1),lambda_y * eye(p*Tini));
    f = [-Q * kron(r',ones(1,N)) * YF zeros(1,p*Tini)];
    Aeq = [[UP;YP] [zeros(m*Tini,p*Tini);-1 * eye(p*Tini)]];
    Aineq = [ [UF;YF]   zeros(m*N + p*N,p*Tini) ];
    
    l = [x_ini;kron(lb,ones(N,1))];
    u = [x_ini;kron(ub,ones(N,1))];
    
    osqpSolver = osqp;
    osqpSolver.setup(H,f,[Aeq;Aineq],l,u);
    
    out = osqpSolver.solve();
    g = out.x;
    U = [UF] * g(1:T-Tini-N+1,1);
else
    l = [x_ini;kron(lb,ones(N,1))];
    u = [x_ini;kron(ub,ones(N,1))];
    f = [-Q * kron(r',ones(1,N)) * YF zeros(1,p*Tini)];
    osqpSolver.update('l', l, 'u', u, 'q', f);
    out = osqpSolver.solve();
    g = out.x;
    U = [UF] * g(1:T-Tini-N+1,1);
end
    
end

