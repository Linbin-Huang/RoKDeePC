% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

% flag_kernel :  1: Gaussian kernel;   2: Exponential kernel; 
%                3: Polynomial kernel; 4: Linear kernel

% flagmode:      1: RoKDeePC; 2: kernel-based MPC; 3: Koopman MPC;
%                4: linear DeePC


Tini = 1; % The length of the initial trajectories
N = 5;   % Prediction horizon
T = 600;  % The length of data trajectories to construct the Hankel matrices

gamma = 0.02; % the regularization parameter in (9)

%% parameters in the objective function
gain = 1000; % a rescaling parameter for the objective function to avoid some too large values causing numerical issues
Q = 1000 / gain;
lambda_k = 1000000*Q / gain;
lambda_g = 5 / gain;
lambda_y = 10*Q / gain;

% constructing R, which also penalizes the rates of changes of control inputs
DM = zeros(N-1,N);
for i = 1:N-1
    DM(i,i) = 1;
    DM(i,i+1) = -1;
end
R = (eye(N) + DM' * DM * 100) / gain;