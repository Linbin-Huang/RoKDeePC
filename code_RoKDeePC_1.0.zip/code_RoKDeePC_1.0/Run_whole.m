% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.

%% choose noie level and random seeds

% M = 0; % small noise level

M = 5; % medium noise level

% M = 40; % high noise level

% some noise random seeds
seed_1 = 76;
seed_2 = 78;
seed_3 = 80;
%% test performance

% flagmode:      1: RoKDeePC; 2: kernel-based MPC; 3: Koopman MPC;
%                4: linear DeePC

% when choosing RoKDeePC or kernel-based MPC
% flag_kernel :  1: Gaussian kernel;   2: Exponential kernel; 
%                3: Polynomial kernel; 4: Linear kernel

flagmode = 1;
flag_kernel = 1;
sim('Data_collection');
sim('RoKDeePC_running');