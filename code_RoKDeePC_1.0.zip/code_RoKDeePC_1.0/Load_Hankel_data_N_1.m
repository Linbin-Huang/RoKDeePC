% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

%% We construct the Hankel matrix to be used in the Koopman MPC algorithm

Tini_x = 1; % The length of the initial trajectories
N_x = 1;   % Prediction horizon is 1, i.e., extended state-space model

for i = 1:T-Tini_x-N_x+1
    for j = 1:Tini_x+N_x
        U1_x(j,i) = U(1,i+j-1);
        Y1_x(j,i) = Y(1,i+j-1);
    end
end

UP1_x = U1_x(1:Tini_x,:);
UF1_x = U1_x(Tini_x+1:Tini_x+N_x,:);

YP1_x = Y1_x(1:Tini_x,:);
YF1_x = Y1_x(Tini_x+1:Tini_x+N_x,:);

UP_x = [UP1_x];
UF_x = [UF1_x];
YP_x = [YP1_x];
YF_x = [YF1_x];
