% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

function [U,f_values] = GD_kernel(N,Tini,T, UP, YP, UF,YF,x_ini, r, K, R, Q, lambda_k, lambda_g, v1, v2, flag, flag_kernel, alpha, U_past)
% this function implements a basic gradient descent algorithm for the
% RoKDeePC and the kernel-based MPC algorithms

% flag:   1: RoKDeePC; 2: kernel-based MPC
m = 1;
p = 1;

%% upper and lower bounds
u_ub = 1;
u_lb = -1;
y_ub = 1;
y_lb = -1;

%% perform gradient descent
Hc = T - Tini - N + 1;

k = zeros(Hc,1);

u = U_past;

for i = 1:Hc
    k(i,1) = kernel0([UP(:,i);YP(:,i);UF(:,i);],[x_ini;u], flag_kernel, alpha);
end

g = zeros(Hc,1);

yref = kron(r,ones(N,1));

step_u = 0.02;      % Here a fixed step size is used for simplicity. 
                    % Interested reader can use more advanced techniques to
                    % choose the step size.

iter_count = 1;
max_iter = 100;     % Here we fixed the iteration number as a baseline.
                    % Interested reader can use other criterion to stop the
                    % gradient descent algorithm.
f_values = zeros(max_iter,1);

du_past = 0;
t_past = 0;

if flag == 1
    while iter_count < max_iter
        
        g = v1  * yref + v2 * k;
        y = YF * g;
        if max(y) > y_ub || min(y) < y_lb
            [g,t_past] = proj_g(N,Tini,T, YF,lambda_g,lambda_k,K,k,t_past,Q,yref,y_ub,y_lb);
        end
        
        du = gradient_cal(u, g, lambda_k, K, k, R, N, Tini, T, UF, p, m, flag_kernel, alpha);
        
        u = u - step_u * (du + du_past);
        
        if max(u) > u_ub
            u = min(u,u_ub * ones(N,1));
        elseif min(u) < u_lb
            u = max(u,u_lb * ones(N,1));
        end
        
        du_past = du;
        
        for i = 1:Hc
            k(i,1) = kernel0([UP(:,i);YP(:,i);UF(:,i);],[x_ini;u], flag_kernel, alpha);
        end
        
        iter_count = iter_count + 1;
        
    end
else
    step_u = 0.02;
    
    KM = YF / K;
    
    M1 = KM' * Q * KM;
    M2 = 2 * yref' * Q * KM;
    
    while iter_count < max_iter
        du = gradient_cal_u(u, k, R, N, Tini, T, UF, p, m, M1, M2, flag_kernel, alpha);
        u = u - step_u * (du + du_past);
        du_past = du;
        
        for i = 1:Hc
            k(i,1) = kernel0([UP(:,i);YP(:,i);UF(:,i);],[x_ini;u], flag_kernel, alpha);
        end
        
        iter_count = iter_count + 1;
    end
end

U = u;

end