% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

function U = KMMPC_OSQP(x_phi,KM_ini,KM_u,Q,R,r,t,pred_N)
% this function solves the Koopman MPC optimization problem using OSQP

m = 1;
p = 1;

ub = [1000;1000];
lb = [-1000;-1000];

global osqpSolver;

if t == 0
    % We initialize the sovler at t = 0.
    H = R + KM_u' * Q * KM_u;
    f = Q * (KM_ini * x_phi - kron(r,ones(pred_N,1)))' * KM_u;
    Aineq = [ eye(m*pred_N); KM_u ];
    
    l = kron(lb,ones(pred_N,1)) - [zeros(pred_N,1);KM_ini * x_phi];
    u = kron(ub,ones(pred_N,1)) - [zeros(pred_N,1);KM_ini * x_phi];
    
    osqpSolver = osqp;
    osqpSolver.setup(H,f,[Aineq],l,u);
    
    out = osqpSolver.solve();
    U = out.x;
else
    f = Q * (KM_ini * x_phi - kron(r,ones(pred_N,1)))' * KM_u;
    osqpSolver.update('q', f);
    out = osqpSolver.solve();
    U = out.x;
end

end

