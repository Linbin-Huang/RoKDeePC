% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

function [du] = gradient_cal(u, g, lambda_k, K, k, R, N, Tini, T, UF, p, m, flag_kernel, alpha)
% compute the gradient with respect to u in the RoKDeePC algorithm

Hc = T - Tini - N + 1;

dkdu = zeros(m*N,Hc);

% flag:  1: Gaussian kernel;  2: Exponential kernel; 3: Polynomial kernel; 4: Linear kernel

if flag_kernel == 1
    for i = 1:Hc
        dkdu(:,i) = - 2 * k(i) * (u - UF(:,i)) / alpha; % For Gaussian kernel
    end
elseif flag_kernel == 2
    for i = 1:Hc
        dkdu(:,i) = k(i) * UF(:,i) / alpha; % For exponential kernel
    end
elseif flag_kernel == 3
    for i = 1:Hc
        dkdu(:,i) = alpha * k(i)^((alpha-1)/alpha) * UF(:,i); % For Polynomial kernel
    end
else
    for i = 1:Hc
        dkdu(:,i) = UF(:,i); % For linear kernel
    end
end

du = 2 * R * u + 2 * lambda_k * dkdu * (k - K * g);

end

