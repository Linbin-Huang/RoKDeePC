% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

%% We perform EDMD in the following, see [11] for more details

num  = 10; % the number of thin plate spline radial basis function

X_rand = rand(2,num) * 3 - 1.5;

Load_Hankel_data_N_1;
Hc_x = T - Tini_x - N_x + 1;

X_km = [UP_x(:,1:Hc_x-1);YP_x(:,1:Hc_x-1)];
Y_km = [UP_x(:,2:Hc_x);YP_x(:,2:Hc_x)];
U_km =  UF_x(:,1:Hc_x-1);

for i = 1:Hc_x-1
    X_phi(:,i) = lifting_f(X_km(:,i),X_rand,num);
    Y_phi(:,i) = lifting_f(Y_km(:,i),X_rand,num);
end

L = length(X_phi(:,1));

m_noise = 0.01;

X_phi = X_phi + rand(L,Hc_x-1) * m_noise - m_noise/2;
Y_phi = Y_phi + rand(L,Hc_x-1) * m_noise - m_noise/2;

AB = Y_phi * pinv([X_phi;U_km]);

A_km = AB(:,1:L);
B_km = AB(:,L+m);

C = X_km * pinv(X_phi);

pred_N = N;

O_t = [];
T_t = zeros(2*pred_N,m*pred_N);

for i = 1:pred_N
    O_t = [O_t;C*A_km^i];
    for j = 1:i
        T_t(2*(i-1)+1:2*i,m*j) = C * A_km^(i-j) * B_km;
    end
end

C_OT_t = [O_t T_t];

Y_OT_t = [];

for i = 1:pred_N
    Y_OT_t = [Y_OT_t;C_OT_t(2*i,:)];
end

KM_ini = Y_OT_t(:,1:L);
KM_u = Y_OT_t(:,L+1:L+m*pred_N);