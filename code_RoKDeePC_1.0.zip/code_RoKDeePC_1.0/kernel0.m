% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

function y = kernel0(x1,x2, flag_kernel, alpha)
% this function calculates the value of the kernel function K

% flag_kernel -- 1: Gaussian kernel;  2: Exponential kernel; 3: Polynomial kernel; 4: Linear kernel

if flag_kernel == 1
    y = exp(- norm(x1-x2,2)^2/alpha); % Gaussian kernel
elseif flag_kernel == 2
    y = exp(x1' * x2 / alpha); % Exponential kernel
elseif flag_kernel == 3
    y = (x1' * x2 + 1)^alpha; % Polynomial kernel
else
    y = x1' * x2; % Linear kernel
end

end

