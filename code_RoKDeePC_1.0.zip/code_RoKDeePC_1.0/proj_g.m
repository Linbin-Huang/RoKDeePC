% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

function [g,t] = proj_g(N,Tini,T, YF,lambda_g,lambda_k,K,k,t_past,Q,yref,y_ub,y_lb)
% This function solves the inner optimization problem that is convex in g,
% corresponding to Step 3 in Algorithm 1 when the output constarint is
% active

t = 1;
Hc = T-Tini-N+1;

global osqpSolver;

if t_past == 0
    % We initialize the sovler at t = 0.
    H = Q * (YF'*YF) + lambda_g * eye(Hc) + lambda_k * K * K;
    f = - Q * yref' * YF - lambda_k * k' * K;
    Aineq = YF;
    
    l = kron(y_lb,ones(N,1));
    u = kron(y_ub,ones(N,1));
    
    osqpSolver = osqp;
    osqpSolver.setup(H,f,Aineq,l,u);
    
    out = osqpSolver.solve();
    g = out.x;
else
    f = - Q * yref' * YF - lambda_k * k' * K;
    osqpSolver.update('q', f);
    out = osqpSolver.solve();
    g = out.x;
end
    
end