% Copyright 2023 ETH Zurich, Linbin Huang (linhuang@ethz.ch, huanglb@zju.edu.cn)
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.
%%

%% We construct the Hankel matrix and Gram matrix in the following

m = 1; % Number of input
p = 1; % number of output

Hc = T - Tini - N + 1;

k = 1; % The control horizon equals "k", namely, we apply the first "k" elements of the optimal control sequence 
       % to the system before solving the optimization problem again.

%%
a = 8/Tc;
b = a + T - 1;

U = [data_uy.signals(1).values(a:b)'];
Y = [data_uy.signals(2).values(a:b)'];


for i = 1:T-Tini-N+1
    for j = 1:Tini+N
        U1(j,i) = U(1,i+j-1);
        Y1(j,i) = Y(1,i+j-1);
    end
end

UP1 = U1(1:Tini,:);
UF1 = U1(Tini+1:Tini+N,:);

YP1 = Y1(1:Tini,:);
YF1 = Y1(Tini+1:Tini+N,:);

UP = [UP1];
UF = [UF1];
YP = [YP1];
YF = [YF1];

Kpred = YF * pinv([UP;YP;UF]);

Kgram = zeros(Hc,Hc);
for i = 1:Hc
    for j = 1:i
        Kgram(i,j) = kernel0([UP(:,i);YP(:,i);UF(:,i)],[UP(:,j);YP(:,j);UF(:,j)], flag_kernel, alpha);
        Kgram(j,i) = Kgram(i,j);
    end
end

Kgram = Kgram + gamma * eye(Hc);

%% pre-compute some parameters for gradient calculation
gain = 1000;
M1 = Q * YF' * YF + lambda_k * Kgram * Kgram + lambda_g * eye(Hc);
v1 = M1 \ (Q * YF');
v2 = M1 \ (lambda_k * Kgram);